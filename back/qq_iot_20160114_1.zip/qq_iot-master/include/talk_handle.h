#ifndef _talk_handle_h
#define _talk_handle_h



int talk_handle_center_up(void);
int talk_push_net_data(void * data );


#endif  /*_talk_handle_h*/