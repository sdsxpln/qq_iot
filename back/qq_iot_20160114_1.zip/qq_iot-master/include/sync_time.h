#ifndef _sync_time_h
#define  _sync_time_h


void sync_time_up(void);


#endif  /*_sync_time_h*/