#ifndef _voice_handle_h
#define _voice_handle_h




int voice_system_start_up(void);
int voice_capture_mic_start(void);
int voice_capture_mic_stop(void);


#endif  /*_voice_handle_h*/